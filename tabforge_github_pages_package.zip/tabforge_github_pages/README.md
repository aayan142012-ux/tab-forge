# TabForge — AP Debate Tabulation

## Publish with GitHub Pages

1. Sign in to GitHub and create a new **public** repository named `tabforge`.
2. In the repository, choose **Add file → Upload files**.
3. Upload `index.html` from this package and commit the change.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then press **Save**.
7. Wait a minute or two and refresh the Pages section. GitHub will show your website link, usually `https://YOUR-USERNAME.github.io/tabforge/`.

## Important limitations

- TabForge stores data in the current browser's local storage. Data does not automatically sync between different devices or different adjudicators' phones.
- Use **Export backup** regularly and keep the backup file safe.
- If you need multiple people to enter ballots at the same time with shared live data, this static version needs a backend/database added first.
